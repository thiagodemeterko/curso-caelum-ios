//: Playground - noun: a place where people can play

// Constantes X Variáveis
let numero1: Int = 10
let numero2: Double = 5.2
var soma = Double(numero1) + numero2

// String
var nome: String = "Carlos"

// Concatenaçao
nome += " Savi"

let nome1 = "Steve Jobs"
let idade = 61
// Se Steve Jobs estivesse vivo, teria 61 anos
let status = "Se \(nome1) estivesse vivo, teria \(idade) anos"
print("Se \(nome1) estivesse vivo, teria \(idade) anos")
print(status)

/*
 Tuplas
 */
let httpCode = 404
let httpMsg = "Not found"
print("Erro: \(httpCode) - Msg: \(httpMsg)")

let http404Error = (404, "Not found")

// Como exibir as informacoes da tupla?
// 1. Por decomposiçao 
let (statusCode, statusMessage) = http404Error

// 2. Pelo índice
print("O código de erro é: \(http404Error.0)")
print("A mensagem de erro é: \(http404Error.1)")

// Comparações em Swift
let valor1 = 10
let valor2 = 20
if valor1 == valor2 {
    print("Valores iguais")
} else {
    print("Valores diferentes")
}

// Loop
//for (i:0; i<10; i++) {
//    print(i)
//}

// Funções em Swift
func sayHello(_ nome: String) -> String {
//    let greeting = "Olá " + nome + "!"
//    return greeting
    // Refatorando
    return "Olá " + nome + "!"
}

// Chamando a função
let resposta = sayHello("Carlos")
print(resposta)

// Definição de classe
class MyClass {
    func mostrarNoConsole(msg: String) {
        print(msg)
    }
}

let minhaClasse = MyClass()
minhaClasse.mostrarNoConsole(msg: "Teste")

/*
 Optional - minimizar a ocorrência de quebra do app devido a valores nulos (ausência de valores)
 */
let possivelNumero = "123"
//var numeroConvertido = Int(possivelNumero)
//var numeroCalculado = numeroConvertido! + 10
//print("Cálculo: \(numeroCalculado)")

// Tratamento de Optional (boas práticas)
// Optional Binding
if let numeroConvertido = Int(possivelNumero) {
    let numeroCalculado = numeroConvertido + 10
    print("Cálculo: \(numeroCalculado)")
} else {
    print("A origem do número é inválida")
}

// For na Swift
var contatos:Array<String> = ["Batman", "Robin", "Coringa"]

for contato in contatos {
    print(contato)
}

contatos.append("Charada")
contatos.remove(at: 2)
contatos
